Project #1: Collatz
Date: Wed, 30 Jan 2013, 8pm

Course Name: CS 327E
Unique: 53355

First Name: Micheal
Last Name: McCaslin
EID: MTM2275
E-mail: Taylor4484@gmail.com
Estimated number of hours: 10
Actual    number of hours: 20

Turnin CS Username: Taylor
GitHub ID: Taylor4484
GitHub Repository Name: cs327e-collatz

Comments:

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
